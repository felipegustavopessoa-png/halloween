# 🎃 Feliz Halloween! — Apresentação Interativa

Uma apresentação de slides com tema Halloween, pronta para GitHub Pages.

## ✨ Recursos

- 12 slides originais com visual Halloween
- Navegação por botões (Anterior / Próximo)
- Controle por teclado: `←` `→` `Espaço` `Home` `End` `F` (fullscreen)
- Auto-play com loop
- Indicadores (dots) clicáveis
- Suporte a swipe no celular
- Tema escuro com laranja e partículas

## 🚀 Como usar no GitHub

1. Crie um repositório novo (ex: `feliz-halloween`)
2. Faça upload desta pasta completa (`index.html` + pasta `halloween_slides/`)
3. Vá em **Settings → Pages**
4. Em **Source** escolha a branch `main` e a pasta `/ (root)`
5. Acesse: `https://seu-usuario.github.io/feliz-halloween/`

## 📁 Estrutura

```
.
├── index.html
├── README.md
└── halloween_slides/
    ├── slide-01.jpg
    ├── slide-02.jpg
    └── ... (até slide-12.jpg)
```

## 🎮 Controles

| Ação              | Como                          |
|-------------------|-------------------------------|
| Próximo slide     | Botão › ou tecla →            |
| Slide anterior    | Botão ‹ ou tecla ←            |
| Auto-play         | Botão ▶ Auto ou tecla Espaço  |
| Ir ao início      | Botão ⏮ ou tecla Home         |
| Ir ao fim         | Botão ⏭ ou tecla End          |
| Tela cheia        | Botão ⛶ ou tecla F            |
| Ir para slide X   | Clique no ponto (dot)         |

---

Feito com 🧡 para o Halloween  
Dia 31 de outubro — Dia Internacional do Halloween
